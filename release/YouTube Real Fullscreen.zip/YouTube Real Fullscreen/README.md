# YouTube Real Fullscreen for Shared Tabs

This keeps YouTube's normal fullscreen button and `f` shortcut working when Volume Master is boosting the tab.

Volume Master uses Chromium's tab-capture API to process audio. Chromium intentionally turns a captured tab's page fullscreen into “fullscreen within the tab,” leaving the browser window and toolbar visible. A userscript cannot override that browser-level decision on its own, so this package uses the smallest native bridge possible for the one missing action: toggling the active Helium window's macOS fullscreen state.

## Behavior

- The userscript listens to YouTube's existing `fullscreenchange` event. It does not add a new button.
- The bridge acts only when Helium is frontmost and its active window title ends with ` - Tab content shared - Helium`.
- Entering YouTube fullscreen enters native macOS fullscreen too.
- Exiting YouTube fullscreen restores the window only when the bridge was responsible for entering fullscreen.
- The bridge listens only on `127.0.0.1:38471` and requires a private request token.

## Install

1. Run `Install Bridge.command`.
2. In System Settings > Privacy & Security > Accessibility, enable **YouTube Real Fullscreen Bridge**. This permission is required because macOS does not let webpage JavaScript control native windows.
3. Open `youtube-real-fullscreen.user.js` with Violentmonkey and choose **Install**.
4. Keep **View > Always Show Toolbar in Full Screen** turned off in Helium. The current Helium profile has already been set this way.

Now use YouTube's regular fullscreen control or press `f`. When Volume Master is active and the tab has the sharing square, the same control enters real fullscreen.

## Uninstall

Disable or delete the userscript in Violentmonkey, then run `Uninstall Bridge.command`. The native bridge and launch agent are moved to Trash, so they remain recoverable.

## Privacy and scope

The bridge performs no network requests. Its loopback server is inaccessible from other computers and accepts only the matching local userscript token. It reads the frontmost Helium window title only long enough to confirm the `Tab content shared` state.
